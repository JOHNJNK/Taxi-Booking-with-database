package Taxi;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author JOHN NK
 */
@WebServlet(urlPatterns = {"/BookingProcess"})
public class BookingProcess extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String pickup = request.getParameter("starting");
        String drop = request.getParameter("droping");
        String pickup_time = request.getParameter("time");
        //System.out.println(pickup + " " + drop + " " + pickup_time);
        //String starting_location=request.getParameter("starting");
        //ArrayList<Car> taxi=TaxiMain.getTaxi();
        //System.out.println(pickup_time);
        int cus_time = timeCalc(pickup_time);
        int startid = locationId(pickup);
        int destinationid = locationId(drop);
        System.out.println("inside booking process");
        int bestchoice = chooseCar(startid, cus_time);
        //Car car = TaxiMain.taxi.get(bestchoice);
        int book_id = 0;
        try {
            Statement stmt = null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxi_booking", "root", "mysql");
            stmt = con.createStatement();
            String sql = "select * from car where id=" + (bestchoice) + "; ";
            ResultSet rs = stmt.executeQuery(sql);
            int id;
            int location = 0;
            int time = 0;
            int profit = 0;
            while (rs.next()) {
                id = rs.getInt(1);
                location = rs.getInt(2);
                time = rs.getInt(3);
                profit = rs.getInt(4);
                System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4) + " ");
            }
            int d = Math.abs(startid - destinationid);
            //int expenses = Math.abs(car.location - startid);
            int expenses = Math.abs(location - startid);
            int gain = d * 150 - (expenses * 75);
            profit+=gain;
            location=destinationid;
            time+= cus_time + (d*15);
            String e_time = convertTime(cus_time + (d * 15));
            System.out.println(profit+" "+location+" "+time);
            sql = "update car set profit="+profit+" where id="+bestchoice;
            stmt.executeUpdate(sql);
            sql = "update car set location="+location+" where id="+bestchoice;
            stmt.executeUpdate(sql);
            sql = "update car set time="+time+" where id="+bestchoice;
            stmt.executeUpdate(sql);
            //sql="update car set profit=? where id=?";
            
            sql = "select count(*) from booking";
            rs=stmt.executeQuery(sql);
            rs.next();
            book_id=rs.getInt(1)+1;
            sql = "insert into booking values(" + (book_id) + ",'"+pickup+"','"+drop+"','"+pickup_time+"','"+e_time+"',"+profit+","+bestchoice+")";
            stmt.executeUpdate(sql);
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println("----------------------------------->"+e);
        }

//        int d = Math.abs(startid - destinationid);
//        int expenses = Math.abs(car.location - startid);
//        int gain = d * 150 - (expenses * 75);
//        car.profit += gain;
//        car.location = destinationid;
//        car.time += cus_time + (d * 15);
//        String e_time = convertTime(cus_time + (d * 15));
//        TaxiMain.booking_id++;
//        System.out.println("Booking ID : " + TaxiMain.booking_id);
//        System.out.println("Allotted Taxi : Taxi-" + car.id);
//
//        Booking book = new Booking(TaxiMain.booking_id, pickup, drop, pickup_time, e_time, gain, car.id);
//        TaxiMain.book_history.add(book);
        System.out.println("Success final");

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet BookingProcess</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<center>");
            out.println("<h1>Booking ID : " + book_id+"</h1>");
            out.println("<h1>Allocated Taxi : Taxi-" + bestchoice + "</h1><br><br>");
            out.println("<form action=\"MainPage.jsp\" method=\"get\">");
            out.println("<button>OK</button>");
            out.println("</form>");
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    private static int chooseCar(int startid, int time) {
        int best = 0, max = 10, profit = 10000000;
        //System.out.println(time+" : Time");

        try {
            Statement stmt = null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxi_booking", "root", "mysql");
            stmt = con.createStatement();
            String sql = "select * from car";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                System.out.println(rs);
                //int o = taxi1.location;
                int o = rs.getInt(2);
                int d = Math.abs(startid - o);
                //int t = taxi1.time + (d * 15);
                int t = rs.getInt(3);
                //System.out.println(max+" "+d);
                //System.out.println(t);
                boolean valid = true;
                int taxi_profit = rs.getInt(4);
                System.out.println(o + " " + t + " " + taxi_profit);
                if (rs.getString(5).equals("Inactive")) {
                    valid = false;
                }
                System.out.println(valid);
                if (valid == true && d < max && t <= time || (valid == true && t == max && t <= time && profit > taxi_profit)) {
                    //System.out.println(profit);
                    max = d;
                    profit = taxi_profit;
                    best = rs.getInt(1);
                }
//                out.println(rs.getString(1));
//                out.println(rs.getString(2));
//                out.println(rs.getString(3));
//                out.println(rs.getString(4));
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println(best + " alogorithm works perfectly");
        return best;
        //System.out.println(taxi.get(best-1));

        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

//    private static int timeConvert(String time) {
//        String a[]=time.split(" ");
//        Stirng x[]=a[0].
//        return
//        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    public static int locationId(String starting) {
        switch (starting) {
            case "DLF":
                return 0;
            case "Velachery":
                return 1;
            case "Tambaram":
                return 2;
            case "T Nagar":
                return 3;
            case "Nungambakkam":
                return 4;
        }
        return -1;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static int timeCalc(String time) {
        String timet[] = time.split(":");
        int total_mins = (Integer.parseInt(timet[0]) * 60) + Integer.parseInt(timet[1]);
        return total_mins;

    }

    private static String convertTime(int i) {

        return String.format("%02d:%02d", i / 60, i % 60);
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
