package Taxi;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author JOHN NK
 */
@WebServlet(urlPatterns = {"/RestWindow"})
public class RestWindow extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RestWindow</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<center>");
            out.println("<h1> BOOKING HISTORY </h1>");
            out.println("<br><br>");
            out.println("<table border=\"1\">");
            out.println("<tr><th>Taxi ID</th><th>Current Status</th></tr>");

            try {
                Statement stmt = null;
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taxi_booking", "root", "mysql");
                stmt = con.createStatement();
                String sql = "select * from car";
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    System.out.println(rs);
                    //int o = taxi1.location;
                    int car_id=rs.getInt(1);
                    String status = rs.getString(5);
                    out.println("<tr><td> Taxi-" + car_id + "</td><td> " + status + "</td></tr>");
//                out.println(rs.getString(1));
//                out.println(rs.getString(2));
//                out.println(rs.getString(3));
//                out.println(rs.getString(4));
                }
                rs.close();
                stmt.close();
                con.close();
            } catch (Exception e) {
                System.out.println(e);
            }

//            for (int i = 0; i < TaxiMain.taxi.size(); i++) {
//                Car car = TaxiMain.taxi.get(i);
//                String status = "Inactive";
//                if (car.valid) {
//                    status = "Active";
//                }
//                out.println("<tr><td> Taxi-" + car.id + "</td><td> " + status + "</td></tr>");
//            }
            out.println("</table>");
            out.println("<br><br>");
            out.println("<form action=\"StatusHandling\" method=\"post\">");
            out.println("<label>Enter the Taxi ID to Change Status : </label>");
            out.println("<input type=\"number\" name=\"taxi\" min=\"1\" >");
            out.println("<br><br><button> OK </button>");
            out.println("</form><br><br>");
            out.println("<form action=\"MainPage.jsp\" method=\"get\">");
            out.println("<button> BACK </button>");
            out.println("</form>");
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
